class WicketBO 
{

public WicketBO(){}
void displayAllWicketDetails(Wicket[] wicketList)
        {
//fill your code
		}


void displaySpecificWicketDetails(Wicket[] wicketList,String Type)
	{
//fill your code
	}
}

