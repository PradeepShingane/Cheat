class OutcomeBO
{
OutcomeBO(){}
void displayAllOutcomeDetails(Outcome[] outcomeList) 
{
//fill your code
}

void displaySpecificOutcomeDetails(Outcome[] outcomList, String date)
{
//fill your code
}

}
