class PlayerBO {
    void displayAllPlayerDetails(Player[] playerList)
    	{
       //fill your code
  	}
    void displaySpecificPlayerDetails(Player[] playerList,String countryName)
	{
       //fill your code
	}

}
