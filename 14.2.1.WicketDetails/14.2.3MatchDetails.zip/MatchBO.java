class MatchBO
{
MatchBO(){}

void displayAllMatchDetails(Match[] matchList)
{
//fill your code
}


void displaySpecificMatchDetails(Match[] matchList, String date)
{
//fill your code
}
}
